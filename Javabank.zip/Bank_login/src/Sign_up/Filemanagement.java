/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sign_up;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;

/**
 *
 * @author me063
 */
public class Filemanagement implements Account_data{
    public void sigupUser(ArrayList<User> acclst){
        String filesignpath = "src/User/UsrList.txt";
        File filesign = new File(filesignpath);
        Formatter outfile = null;
        try {
            outfile = new Formatter(filesign);
            for(User row : acclst){
                outfile.format("%06d;%s;%s;%.2f;%.2f;%s;%s;%s\n",row.getId(),row.getUsername(),row.getPassword(),row.getBalance(),row.getMinbalance(),row.getFirstname(),row.getLastname(),row.getPin());
             }
            System.out.println("Sign Up Success");
            
        } catch (Exception e) {
        }finally{
            if(outfile != null){
                outfile.close();
            }
        }
        
    }
    public void deleteFile(){
        String path = String.format("src/User/%s.txt",data.getUsername());
        File file = new File(path);
        changeInfo(data,true);
        try {
                if(file.delete()){
                    System.out.println(file.getName()+"was removed");
                }
                else{
                    System.out.println(file.getName()+"can not removed");
                }
            } catch (Exception e) {
                System.err.println("An error ocurred.");
            }
    }
    public void writeUserFile(String transaction,double amount,double balance) {
        String filename = String.format("src/User/%s.txt", data.getUsername());
        try (FileWriter fw = new FileWriter(filename, true);  // Open in append mode
             PrintWriter outFile = new PrintWriter(fw)){
             if(transaction.equals("disposit"))
               outFile.printf("Deposit Money;%.2f;%.2f\n",amount,balance);
             else if(transaction.equals("withdraw"))
               outFile.printf("Withdraw Money;%.2f;%.2f\n",amount,balance);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }
    
    public void changeInfo(User u1){
        ArrayList<User> userlst = readFormFile("src/User/UsrList.txt");
        int line = 0;
        for (User row:userlst){
            if(row.getUsername().equals(u1.getUsername())){
                    userlst.set(line, u1);
                    sigupUser(userlst);
                    break;
            }
            line++;
        }
    }
        public void changeInfo(User u1,boolean d){
        ArrayList<User> userlst = readFormFile("src/User/UsrList.txt");
        if(d){
             int line = 0;
            for (User row:userlst){
                if(row.getUsername().equals(u1.getUsername())){
                    break;
            }
            line++;
        }
            userlst.remove(line);
            sigupUser(userlst);
        }

    }
    //method save kar tee write (new account)
    public void recordSignupUser(User acc){
        String filesignpath = "src/User/UsrList.txt";
        ArrayList<User> lst = readFormFile(filesignpath);
        int nextId = 1;
        int maxId = 0;
        for(User data : lst){
            if(data.getId()>maxId){
                maxId = data.getId();
            }
        }nextId = maxId + 1;;
        acc.setId(nextId);
        lst.add(acc);
        sigupUser(lst);
    }
    public ArrayList<User> readFormFile(String filename){
        File files = new File(filename);
        ArrayList<User> lst = new ArrayList<>();
        try {
            Scanner sc = new Scanner(files);
            while(sc.hasNext()){
                String line = sc.nextLine();
                if ((line.equals(""))||(line!=null)){
                    String[] data = line.split(";");
                    int id = Integer.parseInt(data[0]);
                    String us = data[1];
                    String ps = data[2];
                    double balance = Double.parseDouble(data[3]);
                    double minbalance = Double.parseDouble(data[4]);
                    String firstname = data[5];
                    String lastname = data[6];
                    String pin = data[7];
                    User u1 = new User(id,us,ps,balance,minbalance,firstname,lastname,pin);
                    lst.add(u1);  
                }
                
            }
            sc.close();
        } catch (Exception e) {
        }
        return lst;
    }
    public void creatFile(String name){
        File file = new File(String.format("src/User/%s.txt", name));
        try {
            if(file.createNewFile())
                 System.out.println("File created: "+file.getAbsolutePath());
            else{
                System.out.println("Has this account.");
            }
        } catch (IOException e){
            System.err.println(e);
        }
    }
    public boolean checkUser(String us){
        String filesignpath = "src/User/UsrList.txt";
        ArrayList<User> lst = readFormFile(filesignpath);
        for(User acc : lst){
            if(acc.getUsername().equals(us)){
                return true;
            }
        }
        return false;
        
    }
}
