/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sign_up;

/**
 *
 * @author me063
 */
public class User extends Account{

    private double balance;
    private double minbalance;
    private String firstname;
    private String lastname;
    private String pin;
    private boolean loginstate = false;//use for check if the user log in or not
    
    public User(int Id,String username, String Password, double balance, double minbalance,String firstname,String lastname,String pin) {
            this.id = Id;
            this.username = username;
            this.Password = Password;
            this.balance = balance;
            this.minbalance = minbalance;
            this.firstname = firstname;
            this.lastname = lastname;
            this.pin = pin;
    }

    public User(String username, String Password) {
        this.id = 0;
        this.username = username;
        this.Password = Password;
        this.balance = 0;
        this.minbalance = 0;
        this.firstname = " ";
        this.lastname = " ";
        this.pin = "";
    }
    
    //overload
    public User(String firstname,String lastname,String pin,double minbalance){
        this.firstname = firstname;
        this.lastname = lastname;
        this.pin = pin;
        this.minbalance = minbalance;
    }
    
    //default constructor
    public User() {
        this.username = " ";
        this.Password = " ";
        this.balance = 0;
        this.minbalance = 0;
        this.id = 0;
        this.firstname = " ";
        this.lastname = "";
        this.pin = "";
    }

    //getter 
    public boolean isLoginstate() {
        return loginstate;
    }    
    
    public double getBalance() {
        return balance;
    }

    public String getFirstname() {
        return firstname;
    }
    
    public String getLastname() {
        return lastname;
    }
    
    public String getPin() {
        return pin;
    }
    
    public double getMinbalance() {
        return minbalance;
    }
    
    //setter
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    
    public void setLoginstate(boolean loginstate) {
        this.loginstate = loginstate;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setMinbalance(double minbalance) {
        this.minbalance = minbalance;
    }
}
